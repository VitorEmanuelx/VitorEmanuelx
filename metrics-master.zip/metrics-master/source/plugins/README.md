## 🧩 Plugins

Plugins provide additional content and lets you customize rendered metrics.

**📦 Maintained by core team**

* **Core plugins**
  * [🗃️ Base content <sub>`base`</sub>](/source/plugins/base/README.md)
  * [🧱 Core <sub>`core`</sub>](/source/plugins/core/README.md)
* **GitHub plugins**
  * [🏆 Achievements <sub>`achievements`</sub>](/source/plugins/achievements/README.md)
  * [📰 Recent activity <sub>`activity`</sub>](/source/plugins/activity/README.md)
  * [📆 Commit calendar <sub>`calendar`</sub>](/source/plugins/calendar/README.md)
  * [♐ Random code snippet <sub>`code`</sub>](/source/plugins/code/README.md)
  * [🏅 Repository contributors <sub>`contributors`</sub>](/source/plugins/contributors/README.md)
  * [💬 Discussions <sub>`discussions`</sub>](/source/plugins/discussions/README.md)
  * [🎟️ Follow-up of issues and pull requests <sub>`followup`</sub>](/source/plugins/followup/README.md)
  * [🎫 Gists <sub>`gists`</sub>](/source/plugins/gists/README.md)
  * [💡 Coding habits and activity <sub>`habits`</sub>](/source/plugins/habits/README.md)
  * [🙋 Introduction <sub>`introduction`</sub>](/source/plugins/introduction/README.md)
  * [📅 Isometric commit calendar <sub>`isocalendar`</sub>](/source/plugins/isocalendar/README.md)
  * [🈷️ Languages activity <sub>`languages`</sub>](/source/plugins/languages/README.md)
  * [📜 Repository licenses <sub>`licenses`</sub>](/source/plugins/licenses/README.md)
  * [👨‍💻 Lines of code changed <sub>`lines`</sub>](/source/plugins/lines/README.md)
  * [🎩 Notable contributions <sub>`notable`</sub>](/source/plugins/notable/README.md)
  * [🧑‍🤝‍🧑 People <sub>`people`</sub>](/source/plugins/people/README.md)
  * [🗂️ GitHub projects <sub>`projects`</sub>](/source/plugins/projects/README.md)
  * [🎭 Comment reactions <sub>`reactions`</sub>](/source/plugins/reactions/README.md)
  * [📓 Featured repositories <sub>`repositories`</sub>](/source/plugins/repositories/README.md)
  * [🌇 GitHub Skyline <sub>`skyline`</sub>](/source/plugins/skyline/README.md)
  * [💕 GitHub Sponsors <sub>`sponsors`</sub>](/source/plugins/sponsors/README.md)
  * [💝 GitHub Sponsorships <sub>`sponsorships`</sub>](/source/plugins/sponsorships/README.md)
  * [✨ Stargazers <sub>`stargazers`</sub>](/source/plugins/stargazers/README.md)
  * [💫 Star lists <sub>`starlists`</sub>](/source/plugins/starlists/README.md)
  * [🌟 Recently starred repositories <sub>`stars`</sub>](/source/plugins/stars/README.md)
  * [💭 GitHub Community Support <sub>`support`</sub>](/source/plugins/support/README.md) <sub>`⚠️ deprecated`</sub>
  * [📌 Starred topics <sub>`topics`</sub>](/source/plugins/topics/README.md)
  * [🧮 Repositories traffic <sub>`traffic`</sub>](/source/plugins/traffic/README.md)
* **Social plugins**
  * [🌸 Anilist watch list and reading list <sub>`anilist`</sub>](/source/plugins/anilist/README.md)
  * [🗳️ Leetcode <sub>`leetcode`</sub>](/source/plugins/leetcode/README.md)
  * [🎼 Music activity and suggestions <sub>`music`</sub>](/source/plugins/music/README.md)
  * [⏱️ Google PageSpeed <sub>`pagespeed`</sub>](/source/plugins/pagespeed/README.md)
  * [✒️ Recent posts <sub>`posts`</sub>](/source/plugins/posts/README.md)
  * [🗼 Rss feed <sub>`rss`</sub>](/source/plugins/rss/README.md)
  * [🗨️ Stack Overflow <sub>`stackoverflow`</sub>](/source/plugins/stackoverflow/README.md)
  * [🕹️ Steam <sub>`steam`</sub>](/source/plugins/steam/README.md)
  * [🐤 Latest tweets <sub>`tweets`</sub>](/source/plugins/tweets/README.md)
  * [⏰ WakaTime <sub>`wakatime`</sub>](/source/plugins/wakatime/README.md)

**🎲 Maintained by community**
* **[Community plugins](/source/plugins/community/README.md)**
  * [🧠 16personalities <sub>`16personalities`</sub>](/source/plugins/community/16personalities/README.md) by [@lowlighter](https://github.com/lowlighter)
  * [♟️ Chess <sub>`chess`</sub>](/source/plugins/community/chess/README.md) by [@lowlighter](https://github.com/lowlighter)
  * [🥠 Fortune <sub>`fortune`</sub>](/source/plugins/community/fortune/README.md) by [@lowlighter](https://github.com/lowlighter)
  * [💉 Nightscout <sub>`nightscout`</sub>](/source/plugins/community/nightscout/README.md) by [@legoandmars](https://github.com/legoandmars)
  * [💩 PoopMap plugin <sub>`poopmap`</sub>](/source/plugins/community/poopmap/README.md) by [@matievisthekat](https://github.com/matievisthekat)
  * [📸 Website screenshot <sub>`screenshot`</sub>](/source/plugins/community/screenshot/README.md) by [@lowlighter](https://github.com/lowlighter)
  * [🦑 Splatoon <sub>`splatoon`</sub>](/source/plugins/community/splatoon/README.md) by [@lowlighter](https://github.com/lowlighter)
  * [💹 Stock prices <sub>`stock`</sub>](/source/plugins/community/stock/README.md) by [@lowlighter](https://github.com/lowlighter)

