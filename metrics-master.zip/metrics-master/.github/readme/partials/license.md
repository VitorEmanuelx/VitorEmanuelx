## 📜 License

```
MIT License
Copyright (c) 2020-present lowlighter
```

![Sponsors](https://github.com/lowlighter/metrics/blob/examples/metrics.sponsors.svg)
