### 📝 Reporting a Vulnerability

To report a vulnerability, simply open an [issue](https://github.com/lowlighter/metrics/issues).
We'll try to patch it quickly.
